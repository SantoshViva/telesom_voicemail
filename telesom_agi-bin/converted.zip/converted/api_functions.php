<?php
function profilequery($action,$msisdn) 
{

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'http://149.28.148.198:7070/crbt/core/profilequery',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>'{"cpid": "CRBT","msisdn": "'.$msisdn.'","action": "ProfileQuery"}',
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/json'
  ),
));

$response = curl_exec($curl);
curl_close($curl);
return $response;

}

function deactivation($action,$msisdn)
{

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'http://149.28.148.198:7070/crbt/core/unsubscription',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>'{"cpid": "CRBT","msisdn": "'.$msisdn.'","tid": "7dc23952-d604-464a-bcd4-a1d7324a54c88","action": "UNSUBSCRIPTION","serviceid": "SUBS_RENTAL","productid": "DAILY_RBT","langid": "en","interfacename": "IVR","timestamp":"20200809102030","issubcharge": "Y","toneid": "01011062100560","tonetype": "0","tonetypeidx": "1","tonename": "Dua5_Ram","precrbtflag": "","callingpartynumber": "D","toneserviceid": "TONE_RENTAL","toneproductid": "TONE_LIFETIME","istonecharge": "N"}',
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/json'
  ),
));

$response = curl_exec($curl);
curl_close($curl);
return $response;

}

function activation($action,$msisdn)
{

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'http://149.28.148.198:7070/crbt/core/subscription',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>'{"cpid": "CRBT","msisdn": "'.$msisdn.'","tid": "7dc23952-d604-464a-bcd4-a1d7324a54c88","action": "SUBSCRIPTION","serviceid": "SUBS_RENTAL","productid": "DAILY_RBT","langid": "en","interfacename": "IVR","timestamp":"20200809102030","issubcharge": "Y","toneid": "01011062100560","tonetype": "0","tonetypeidx": "1","tonename": "Dua5_Ram","precrbtflag": "","callingpartynumber": "D","toneserviceid": "TONE_RENTAL","toneproductid": "TONE_LIFETIME","istonecharge": "N"}',
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/json'
  ),
));

$response = curl_exec($curl);
curl_close($curl);
return $response;

}



?>
